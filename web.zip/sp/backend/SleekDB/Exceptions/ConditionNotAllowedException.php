<?php


namespace SleekDB\Exceptions;

class ConditionNotAllowedException extends \Exception {}
